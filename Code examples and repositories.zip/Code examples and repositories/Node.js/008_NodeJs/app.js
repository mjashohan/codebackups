// To import use require and store in local variable
// ./ means current directory
var movies = require('./movies');
movies.avatar();