var movies = require('./movies');
movies.favMovie = "The Notebook";
console.log("Emily's favorite movie is: " + movies.favMovie);