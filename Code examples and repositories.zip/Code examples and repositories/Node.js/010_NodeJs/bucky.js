var movies = require('./movies');
console.log("Bucky's favorite movie is: " + movies.favMovie);