var movies = require('./movies');
movies.printAvatar();
console.log(movies.favMovie);