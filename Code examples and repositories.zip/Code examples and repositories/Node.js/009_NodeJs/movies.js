module.exports = {

    printAvatar: function(){
        console.log("Avatar");
    },

    printChappie: function(){
        console.log("Chappie");
    },

    favMovie: "The Matrix"

};