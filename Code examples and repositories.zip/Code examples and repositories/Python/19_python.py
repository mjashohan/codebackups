groceries = {'cereal', 'milk', 'starcrunch', 'beer', 'duck tape', 'lotion', 'beer'}
print(groceries)

if 'milk' in groceries:
  print("You already have milk hoss!")
else:
  print("Oh yea, you need milk!")
