def dumb_sentence(name='Bucky', action='ate', item='tuna'):
  print(name, action, item)

dumb_sentence()
dumb_sentence("Sally", "farts", "gently")
dumb_sentence(item='awesome')
dume_sentence(item='awesome', action='is')
