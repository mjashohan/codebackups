classmates = {'Tony': ' cool but smells', 'Emma': ' sits behind me', 'Lucy': ' asks too many questions'}

for k, v in classmates.items():
    print(k + v)
