# You can try different ages and names..

#age = 27
age = 13

if age < 21:
    print("No beer for you!")

#name = "Lucy"
name = "Tommy D"
if name is "Bucky":
    print("Hey there Bucky")
elif name is "Lucy":
    print("What up Lucedawg")
elif name is "Sammy":
    print("What up Slammy")
else:
    print("Please sign up for the site!")
