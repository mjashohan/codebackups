answer = lambda x: x*7
print(answer(5))