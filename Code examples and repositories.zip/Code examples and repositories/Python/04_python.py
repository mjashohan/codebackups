>>> user = "Tuna McFish"
>>> user[0]
'T'
>>> user[5]
'M'
>>> user[-1]
'h'
>>> user[-3]
'i'
>>> user[2:7]
'na Mc'
>>> user[:7]
'Tuna Mc'
>>> user[2:]
'na McFish'
>>> user[:]
'Tuna McFish'
>>> print('dsadasd')
dsadasd
>>> len('dfjhf22893hfsdfjkasdf')
21
>>> len(user)
11