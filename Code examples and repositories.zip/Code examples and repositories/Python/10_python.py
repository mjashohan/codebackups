magicNumber = 26

# ok this program find a magic number

'''
multiple comment
print("Bucky" + "Roberts")
'''

for n in range(101):
    if n is magicNumber:
        print(n, "is the magic number ! ")
        break
    else:
        print(n)