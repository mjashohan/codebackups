__author__ = 'Aybars'
print('I hope this works')
tuna = 5-1
print(tuna)