def fish():
    print('I am a tuna feesh!')
