def beef():
    print("Dayum, functions are cool")


def bitcoin_to_usd(btc):
    amount = btc * 527
    print(amount)

beef()
bitcoin_to_usd(3.85)
bitcoin_to_usd(1)
bitcoin_to_usd(13)