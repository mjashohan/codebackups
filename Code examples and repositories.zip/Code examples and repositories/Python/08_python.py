# food list and inside some items
foods = ['bacon', 'tuna', 'ham', 'snausages', 'beef']

for f in foods[:2]:
    print(f)
    print(len(f))