import tuna_21
import random

tuna_21.fish()

x = random.randrange(1, 1000)
print(x)