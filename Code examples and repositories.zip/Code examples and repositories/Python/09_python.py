#from 0 to 10
for x in range(10):
    print(x)

print("")

#from 5 to 12
for x in range(5, 12):
    print(x)

print("")

#from 10 to 40 increment value 5
for x in range(10, 40, 5):
    print(x)

print("")

#While loop

buttcrack = 5

while(buttcrack < 10):
    print(buttcrack)
    buttcrack += 1