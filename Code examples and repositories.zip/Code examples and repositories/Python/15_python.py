a = 7823


def corn():
  print(a)


def fudge():
  print(a)

corn()
fudge()
