// This is a single-line comment.

/* This is a multi-line comment */

document.write("i love ham");
document.write("and i love bacon too");