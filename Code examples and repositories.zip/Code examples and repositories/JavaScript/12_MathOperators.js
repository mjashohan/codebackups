/* 

+	Addition
-	Subtraction
*	Multiplication
/	Division
%	Modulus
++	Increment
--	Decrement

*/

var apples = 4 * 4;
document.write(apples);

// Methods to increment
// First Example
var chop = 7;
chop = chop + 1;
document.write(chop);

// Second Example
chop++;

// Decrement
chop--;