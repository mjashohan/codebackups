// First Exaple
var name = "Bucky";
var age  = 24;
document.write(name + " is my name and my age is " + age);

// Second Example
var tuna  = "i am a fish";
var bacon = "baconator?"
var ham   = "hamburglarr"
document.write(tuna+bacon+ham); 