// JavaScript Data Types

var tuna = 20; // Number

var tuna = "text in here"; // String

var tuna = true; // or false are known as: Booleans

document.write(tuna);