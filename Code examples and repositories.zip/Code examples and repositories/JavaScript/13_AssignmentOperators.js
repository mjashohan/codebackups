var bucky = 24;

bucky += 67;
bucky -= 32;
bucky *= 4;
bucky /= 5;
// You can also use %=	
document.write(bucky);