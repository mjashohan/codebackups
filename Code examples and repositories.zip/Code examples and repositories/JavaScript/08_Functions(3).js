function apples(one, two) {
	document.write(one + " is better than " + two + "<br/>");
}

apples("Bucky", "Hobart");
apples("Counting Crows", "Bieber");
apples("strawberry", "coconut");