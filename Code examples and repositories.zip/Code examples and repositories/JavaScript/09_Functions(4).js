// First Example
function tooEasy() {
	return "Gametime";
}

document.write(tooEasy());

// Second Example
function addNumbers(a, b) {
	var c = a + b;
	return c;
}

document.write(addNumbers(3,6));