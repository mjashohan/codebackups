function meatball(x) {
	alert("I love " + x);
}

meatball("bacon");
meatball("Natalie Protman");
meatball("Good Will Hunting");