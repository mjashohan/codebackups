// Global Variable
var girl = " Kelsey ";

function spit() {
	// Local Variable
	// var girl = " Kelsey ";
	document.write(girl);
};

spit();