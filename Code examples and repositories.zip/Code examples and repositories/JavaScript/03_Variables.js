var bucky = 32;
document.write(bucky);