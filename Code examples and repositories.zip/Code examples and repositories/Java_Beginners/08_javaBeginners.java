import java.util.Scanner;

public class apples{
    public static void main(String args[]){
    
        int girls, boys, people;
        girls = 6;
        boys = 3;
        people = girls + boys; /*-, /, *, % are possible */
        System.out.println(people);
        
    }
}