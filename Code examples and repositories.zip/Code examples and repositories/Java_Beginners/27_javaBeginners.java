class apples{
    public static void main(String[] args){
        
        int bucky[]=(2,4,5,7,9);
        
        System.out.println(bucky[2]);
    }
}