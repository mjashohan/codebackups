public class apples {
    public static void main (String[] args){
        int firstarray[][] = {{8,9,10,11},{12,13,14,15}};
        int secondarray[][] = {{30,31,32,33},{43},{4,5,6}}; 
    }

}