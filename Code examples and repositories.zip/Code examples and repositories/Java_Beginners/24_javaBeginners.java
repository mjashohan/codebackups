class apples{
    public static void main(String[] args){
        int counter = 0;

        do{
            System.out.println(counter);
            counter++
        }while(counter <=10);
    }
}