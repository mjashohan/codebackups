class apples{
    public static void main(String args[]){
    
        tuna tunaObject = new tuna();
        tunaObject.simpleMessage();
    
    }
}


public class tuna {
    public void simpleMessage(){
        System.out.println("This is another class");
    }
}