class apples{
    public static void main(String[] args){
        System.out.println(Math.(abs, ceil, floor, max, min, pow, sqrt all can apply after dot seporator)(1));
    }
}