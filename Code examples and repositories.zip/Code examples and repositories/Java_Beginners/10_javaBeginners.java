public class apples{
    public static void main(String args[]){
        int test = 6;
        
        if (test == 9){    
            System.out.println("Yes");
        }else{
            System.out.println("This is else");    
        }
    }
}