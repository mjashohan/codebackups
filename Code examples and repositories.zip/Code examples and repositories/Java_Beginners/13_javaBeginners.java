class apples{
    public static void main(String args[]){
        int counter = 0;
        while (counter < 10){
            System.out.println(counter);
            counter++;
        }
    }
}