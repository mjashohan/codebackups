import java.util.Scanner;

class apples{
    public static void main(String args[]){
        Scanner bucky = new Scanner(System.in);
        System.out.println(bucky.nextLine());
    }
}