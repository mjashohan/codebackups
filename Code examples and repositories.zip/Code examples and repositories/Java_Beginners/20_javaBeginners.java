class apples{
    public static void main(String args[]){
        int age = 21;

        System.out.println(age > 50 ? "You are old" : "You are young");

    }
}